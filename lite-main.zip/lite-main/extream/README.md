```
source <(curl -sL https://raw.githubusercontent.com/rullpqh/lite/main/extream/setup.sh)
```
